package br.com.fiap.model;

public class Login {
	
	private String id_lg;
	private String email_lg;
	private String senha_lg;
	
	public Login() {}
	
	public Login(String id_lg, String email_lg, String senha_lg) {
		this.id_lg = id_lg;
		this.email_lg = email_lg;
		this.senha_lg = senha_lg;
	}

	public String getId_lg() {
		return id_lg;
	}
	public void setId_lg(String id_lg) {
		this.id_lg = id_lg;
	}
	public String getEmail_lg() {
		return email_lg;
	}
	public void setEmail_lg(String email_lg) {
		this.email_lg = email_lg;
	}
	public String getSenha_lg() {
		return senha_lg;
	}
	public void setSenha_lg(String senha_lg) {
		this.senha_lg = senha_lg;
	}
}
