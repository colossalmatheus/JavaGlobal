package br.com.fiap.model;

public class Cliente extends Cadastro{
	
	private int cpf_cl;
	private String nm_cl;
	private String dt_nasc;
	
	public Cliente(){}
	
	public Cliente(int cpf_cl, String nm_cl, String dt_nasc) {
		this.cpf_cl = cpf_cl;
		this.nm_cl = nm_cl;
		this.dt_nasc = dt_nasc;
	}




	public int getCpf_cl() {
		return cpf_cl;
	}




	public void setCpf_cl(int cpf_cl) {
		this.cpf_cl = cpf_cl;
	}




	public String getNm_cl() {
		return nm_cl;
	}




	public void setNm_cl(String nm_cl) {
		this.nm_cl = nm_cl;
	}




	public String getDt_nasc() {
		return dt_nasc;
	}




	public void setDt_nasc(String dt_nasc) {
		this.dt_nasc = dt_nasc;
	}


}