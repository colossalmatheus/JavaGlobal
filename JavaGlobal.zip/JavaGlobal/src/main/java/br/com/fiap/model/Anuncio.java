package br.com.fiap.model;

public class Anuncio {
	
	private int id_an;
	private String emp_an;
	private String desc_an;
	
	public Anuncio() {}
	
	public Anuncio(int id_an, String emp_an, String desc_an) {
		this.id_an = id_an;
		this.emp_an = emp_an;
		this.desc_an = desc_an;
	}

	public int getId_an() {
		return id_an;
	}

	public void setId_an(int id_an) {
		this.id_an = id_an;
	}

	public String getEmp_an() {
		return emp_an;
	}

	public void setEmp_an(String emp_an) {
		this.emp_an = emp_an;
	}

	public String getDesc_an() {
		return desc_an;
	}

	public void setDesc_an(String desc_an) {
		this.desc_an = desc_an;
	}
}
