package br.com.fiap.banco.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;


import br.com.fiap.banco.dao.CadastroDao;
import br.com.fiap.banco.exception.BadInfoException;
import br.com.fiap.banco.exception.IdNotFoundException;
import br.com.fiap.banco.factory.ConnectionFactory;
import br.com.fiap.bo.CadastroBo;
import br.com.fiap.bo.Excecao;
import br.com.fiap.model.Cadastro;

public class CadastroService {
	
private CadastroDao cadastroDao;
private CadastroBo cadastrobo;
	
	public CadastroService() throws ClassNotFoundException, SQLException {
		Connection conn = ConnectionFactory.getConnection();
		cadastroDao = new CadastroDao(conn);
		cadastrobo = new CadastroBo();

	}
	
	
	public void cadastrar(Cadastro cadastro) throws ClassNotFoundException, SQLException, BadInfoException, Excecao {
		cadastrobo.cadastrarBO(cadastro);
	}
	
	
	public List<Cadastro> listar() throws ClassNotFoundException, SQLException{
		return cadastroDao.listar();
	}
	
	public void remover(String id_cd) throws ClassNotFoundException, SQLException, IdNotFoundException {
		cadastroDao.remover(id_cd);
	}

	
	public void atualizar(Cadastro cadastro) throws ClassNotFoundException, SQLException, IdNotFoundException, BadInfoException {
		cadastroDao.atualizar(cadastro);
	}


	public CadastroBo getCadastrobo() {
		return cadastrobo;
	}


	public void setCadastrobo(CadastroBo cadastrobo) {
		this.cadastrobo = cadastrobo;
	}

	
	

}
