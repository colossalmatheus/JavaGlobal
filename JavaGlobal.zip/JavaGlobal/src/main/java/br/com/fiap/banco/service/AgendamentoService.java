package br.com.fiap.banco.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import br.com.fiap.banco.dao.AgendamentoDao;
import br.com.fiap.banco.exception.BadInfoException;
import br.com.fiap.banco.exception.IdNotFoundException;
import br.com.fiap.banco.factory.ConnectionFactory;
import br.com.fiap.bo.AgendamentoBo;
import br.com.fiap.bo.Excecao;
import br.com.fiap.model.Agendamento;

public class AgendamentoService {

private AgendamentoDao agendamentoDao;
private AgendamentoBo agendamentobo;
	
	public AgendamentoService() throws ClassNotFoundException, SQLException {
		Connection conn = ConnectionFactory.getConnection();
		agendamentoDao = new AgendamentoDao(conn);
		agendamentobo = new AgendamentoBo();
	}
	
	
	public void cadastrar(Agendamento agendamento) throws ClassNotFoundException, SQLException, BadInfoException, Excecao {
		agendamentobo.cadastrarBO(agendamento);
		
	}
	
	
	public List<Agendamento> listar() throws ClassNotFoundException, SQLException{
		return agendamentoDao.listar();
	}
	
	public void remover(String id_ag) throws ClassNotFoundException, SQLException, IdNotFoundException {
		agendamentoDao.remover(id_ag);
	
	}

	
	public void atualizar(Agendamento agendamento) throws ClassNotFoundException, SQLException, IdNotFoundException, BadInfoException {
		agendamentoDao.atualizar(agendamento);
	}

	
	


}
