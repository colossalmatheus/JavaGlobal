package br.com.fiap.banco.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;


import br.com.fiap.banco.dao.LoginDao;
import br.com.fiap.banco.exception.BadInfoException;
import br.com.fiap.banco.exception.IdNotFoundException;
import br.com.fiap.banco.factory.ConnectionFactory;
import br.com.fiap.model.Login;

public class LoginService {
	
private LoginDao loginDao;
	
	public LoginService() throws ClassNotFoundException, SQLException {
		Connection conn = ConnectionFactory.getConnection();
		loginDao = new LoginDao(conn);

	}
	
	
	public boolean cadastrar(Login login) throws ClassNotFoundException, SQLException, BadInfoException {
		return loginDao.cadastrar(login);
	}
	
	
	public List<Login> listar() throws ClassNotFoundException, SQLException{
		return loginDao.listar();
	}
	
	public void remover(String id_lg) throws ClassNotFoundException, SQLException, IdNotFoundException {
		loginDao.remover(id_lg);
	}

	
	public void atualizar(Login login) throws ClassNotFoundException, SQLException, IdNotFoundException, BadInfoException {
		loginDao.atualizar(login);
	}

	
	


}