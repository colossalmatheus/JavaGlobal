package br.com.fiap.banco.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.banco.exception.IdNotFoundException;

import br.com.fiap.model.Login;

public class LoginDao {
	
	
	
	private Connection conn;

	public LoginDao(Connection conn) {
		this.conn = conn;
	}

	public boolean cadastrar(Login login) throws ClassNotFoundException, SQLException {
	    PreparedStatement tentativa = conn.prepareStatement("SELECT * FROM cadastro WHERE email_cd = ? AND senha_cd = ?");
	    tentativa.setString(1, login.getEmail_lg());
	    tentativa.setString(2, login.getSenha_lg());

	    ResultSet resultSet = tentativa.executeQuery();

	    boolean registroExiste = resultSet.next();
	    

	    if (registroExiste) {
	        return true;
	    } else {
	        return false;
	    }
	}

	public List<Login> listar() throws ClassNotFoundException, SQLException {

		PreparedStatement stm = conn.prepareStatement("select * from login");

		ResultSet result = stm.executeQuery();
		List<Login> lista = new ArrayList<Login>();

		while (result.next()) {
			Login login = parse(result);
			lista.add(login);
		}
		return lista;

	}

	private Login parse(ResultSet result) throws SQLException {

		String id_lg = result.getString("id_lg");
		String email_lg = result.getString("email_lg");
		String senha_lg = result.getString("senha_lg");
		
		
	

		Login login = new Login(id_lg,email_lg,senha_lg);
		
	
		return login;
	}
	
	
	public void remover(String id_lg) throws ClassNotFoundException, SQLException, IdNotFoundException {

		// PreparedStatement
		PreparedStatement stm = conn.prepareStatement("delete from login where id_lg = ?");
		// Setar os parametros na Query
		stm.setString(1, id_lg);
		// Executar a Query
		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Login nao encontrado para remocao");
		
	}

	public void atualizar(Login login) throws ClassNotFoundException, SQLException, IdNotFoundException {
		PreparedStatement stm = conn.prepareStatement("update login set senha_lg = ? where id_lg = ?");
		stm.setString(1, login.getSenha_lg());
		stm.setString(2, login.getId_lg());

		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Id nao encontrado para atualizar");
		
	}
	
	

}