package br.com.fiap.model;

public class EmpresasDoadoras {
	
	private int id_ed;
	private String nm_ed;
	private String tipo_ed;
	
	
	public EmpresasDoadoras() {}


	public EmpresasDoadoras(int id_ed, String nm_ed, String tipo_ed) {
		this.id_ed = id_ed;
		this.nm_ed = nm_ed;
		this.tipo_ed = tipo_ed;
	}


	public int getId_ed() {
		return id_ed;
	}


	public void setId_ed(int id_ed) {
		this.id_ed = id_ed;
	}


	public String getNm_ed() {
		return nm_ed;
	}


	public void setNm_ed(String nm_ed) {
		this.nm_ed = nm_ed;
	}


	public String getTipo_ed() {
		return tipo_ed;
	}


	public void setTipo_ed(String tipo_ed) {
		this.tipo_ed = tipo_ed;
	}
	
	
}
