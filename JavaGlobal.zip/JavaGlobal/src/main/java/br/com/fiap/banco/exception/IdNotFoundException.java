package br.com.fiap.banco.exception;

public class IdNotFoundException extends Exception {

	public IdNotFoundException(String mensagem) {
		super(mensagem);
	}
	
}