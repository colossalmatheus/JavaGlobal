package br.com.fiap.banco.resource;

import java.sql.SQLException;
import java.util.List;

import br.com.fiap.banco.exception.BadInfoException;
import br.com.fiap.banco.exception.IdNotFoundException;
import br.com.fiap.banco.service.AgendamentoService;
import br.com.fiap.bo.Excecao;
import br.com.fiap.model.Agendamento;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import jakarta.ws.rs.core.UriBuilder;
import jakarta.ws.rs.core.UriInfo;

@Path("/agendamento")
public class AgendamentoResource {

	private AgendamentoService service;

	public AgendamentoResource() throws ClassNotFoundException, SQLException {
		service = new AgendamentoService();
	}

	// POST http://localhost:8080/07-WebApi/api/acessorio/ (Cadastrar um
	// acessorio)
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response cadastrar(Agendamento agendamento, @Context UriInfo uri)
			throws ClassNotFoundException, SQLException, Excecao {
		try {
			service.cadastrar(agendamento);
			// Recupera o path (URL atual(http://localhost:8080/07-WebApi/api/acessorio/))
			UriBuilder uriBuilder = uri.getAbsolutePathBuilder();
			// Adiciona o nome do acessorio que foi criado na URL
			// uriBuilder.path(String.valueOf(funcionario.getNome()));
			uriBuilder.path((agendamento.getId_ag()));
			// Retornar o status 201 com a URL para acessar o acessorio criado
			return Response.created(uriBuilder.build()).build();
		} catch (BadInfoException e) {
			e.printStackTrace();
			// Retornar o status 400 bad request
			return Response.status(Status.BAD_REQUEST).entity(e.getMessage()).build();
		}
	}

	// GET http://localhost:8080/07-WebApi/api/acessorio (Listar todos os
	// funcionarios)
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Agendamento> lista() throws ClassNotFoundException, SQLException {
		return service.listar();
	}

	// DELETE http://localhost:8080/07-WebApi/api/acessorio/garfo (Apagar um produto)
	@DELETE
	@Path("/{id_ag}")
	public Response remover(@PathParam("id_ag") String id_ag) throws ClassNotFoundException, SQLException {
		try {
			service.remover(id_ag);
			return Response.noContent().build();
		} catch (IdNotFoundException e) {
			return Response.status(Status.NOT_FOUND).build();
		}
	}

	// PUT http://localhost:8080/07-WebApi/api/acessorio/1 (Atualizar um acessorio)
	@PUT
	@Path("/{id_ag}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response atualizar(Agendamento agendamento, @PathParam("id_ag") String id_ag)
			throws ClassNotFoundException, SQLException {
		try {
			agendamento.setId_ag(id_ag);
			service.atualizar(agendamento);
			return Response.ok().build();
		} catch (IdNotFoundException e) {
			return Response.status(Status.NOT_FOUND).build();
		} catch (BadInfoException e) {
			return Response.status(Status.BAD_REQUEST).entity(e.getMessage()).build();
		}
	}

}
