package br.com.fiap.banco.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.banco.exception.IdNotFoundException;
import br.com.fiap.model.Agendamento;

public class AgendamentoDao {

	private Connection conn;

	public AgendamentoDao(Connection conn) {
		this.conn = conn;
	}

	public void cadastrar(Agendamento agendamento) throws ClassNotFoundException, SQLException {

		
		PreparedStatement stm = conn.prepareStatement("INSERT INTO agendamento (id_ag,titulo_ag,datahr_ag,link_ag) values (?,?,?,?)");

		
		stm.setString(1, agendamento.getId_ag());
		stm.setString(2, agendamento.getTitulo_ag());
		stm.setString(3,agendamento.getDatahr_ag());
		stm.setString(4,agendamento.getLink_ag());

		
		stm.executeUpdate();
		
	}

	public List<Agendamento> listar() throws ClassNotFoundException, SQLException {

		PreparedStatement stm = conn.prepareStatement("select * from agendamento");

		ResultSet result = stm.executeQuery();
		List<Agendamento> lista = new ArrayList<Agendamento>();

		while (result.next()) {
			Agendamento agendamento = parse(result);
			lista.add(agendamento);
		}
		

		return lista;
	}

	private Agendamento parse(ResultSet result) throws SQLException {

		String id_ag = result.getString("id_ag");
		String titulo_ag = result.getString("titulo_ag");
		String datahr_ag = result.getString("datahr_ag");
		String link_ag = result.getString("link_ag");
		
	

		Agendamento agendamento = new Agendamento(id_ag,titulo_ag,datahr_ag,link_ag);

		
		return agendamento;
	}
	
	
	public void remover(String id_ag) throws ClassNotFoundException, SQLException, IdNotFoundException {

		// PreparedStatement
		PreparedStatement stm = conn.prepareStatement("delete from agendamento where id_ag = ?");
		// Setar os parametros na Query
		stm.setString(1, id_ag);
		// Executar a Query
		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Agendamento nao encontrado para remocao");
		
	}

	public void atualizar(Agendamento agendamento) throws ClassNotFoundException, SQLException, IdNotFoundException {
		PreparedStatement stm = conn.prepareStatement("update agendamento set link_ag = ? where id_ag = ?");
		stm.setString(1, agendamento.getLink_ag());
		stm.setString(2, agendamento.getId_ag());

		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Id nao encontrado para atualizar");
		
	}
	
	

}