package br.com.fiap.banco.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.banco.exception.IdNotFoundException;
import br.com.fiap.model.Especialista;

public class EspecialistaDao {
	
	private Connection conn;

	public EspecialistaDao(Connection conn) {
		this.conn = conn;
	}

	public void cadastrar(Especialista especialista) throws ClassNotFoundException, SQLException {

		
		PreparedStatement stm = conn.prepareStatement("INSERT INTO especialista (crm_md,espc_md,nm_md,fone_md) values (?,?,?,?)");

		
		stm.setString(1, especialista.getCrm_md());
		stm.setString(2, especialista.getEspc_md());
		stm.setString(3,especialista.getNm_md());
		stm.setString(4,especialista.getFone_md());

		
		stm.executeUpdate();
		
	}

	public List<Especialista> listar() throws ClassNotFoundException, SQLException {

		PreparedStatement stm = conn.prepareStatement("select * from especialista");

		ResultSet result = stm.executeQuery();
		List<Especialista> lista = new ArrayList<Especialista>();

		while (result.next()) {
			Especialista especialista = parse(result);
			lista.add(especialista);
		}
		
		return lista;
	}

	private Especialista parse(ResultSet result) throws SQLException {

		String crm_md = result.getString("crm_md");
		String espc_md = result.getString("espc_md");
		String nm_md = result.getString("nm_md");
		String fone_md = result.getString("fone_md");
		
	

		Especialista especialista = new Especialista(crm_md,espc_md,nm_md,fone_md);
		
		
		return especialista;
	}
	
	
	public void remover(String crm_md) throws ClassNotFoundException, SQLException, IdNotFoundException {

		// PreparedStatement
		PreparedStatement stm = conn.prepareStatement("delete from especialista where crm_md = ?");
		// Setar os parametros na Query
		stm.setString(1, crm_md);
		// Executar a Query
		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Especialista nao encontrado para remocao");
		
	}

	public void atualizar(Especialista especialista) throws ClassNotFoundException, SQLException, IdNotFoundException {
		PreparedStatement stm = conn.prepareStatement("update agendamento set fone_md = ? where crm_md = ?");
		stm.setString(1, especialista.getFone_md());
		stm.setString(2, especialista.getCrm_md());

		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Crm nao encontrado para atualizar");
		
	}
	
	

}