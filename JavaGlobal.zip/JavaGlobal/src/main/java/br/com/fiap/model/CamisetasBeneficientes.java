package br.com.fiap.model;

public class CamisetasBeneficientes {

	private int id_cb;
	private String cor_cb;
	private String tam_cb;
	private String whatsapp_cb;
	
	public CamisetasBeneficientes () {}

	public CamisetasBeneficientes(int id_cb, String cor_cb, String tam_cb, String whatsapp_cb) {
		this.id_cb = id_cb;
		this.cor_cb = cor_cb;
		this.tam_cb = tam_cb;
		this.whatsapp_cb = whatsapp_cb;
	}

	public int getId_cb() {
		return id_cb;
	}

	public void setId_cb(int id_cb) {
		this.id_cb = id_cb;
	}

	public String getCor_cb() {
		return cor_cb;
	}

	public void setCor_cb(String cor_cb) {
		this.cor_cb = cor_cb;
	}

	public String getTam_cb() {
		return tam_cb;
	}

	public void setTam_cb(String tam_cb) {
		this.tam_cb = tam_cb;
	}

	public String getWhatsapp_cb() {
		return whatsapp_cb;
	}

	public void setWhatsapp_cb(String whatsapp_cb) {
		this.whatsapp_cb = whatsapp_cb;
	}
	


}
