package br.com.fiap.bo;

public class Excecao extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Excecao(String recebe) {
		
	}

}
