package br.com.fiap.model;

public class Arrecadacao {
	
	private int id_ar;
	private String razao_ar;
	private String chave_pix_ar;


	public Arrecadacao() {}


	public Arrecadacao(int id_ar, String razao_ar, String chave_pix_ar) {
		this.id_ar = id_ar;
		this.razao_ar = razao_ar;
		this.chave_pix_ar = chave_pix_ar;
	}


	public int getId_ar() {
		return id_ar;
	}


	public void setId_ar(int id_ar) {
		this.id_ar = id_ar;
	}


	public String getRazao_ar() {
		return razao_ar;
	}


	public void setRazao_ar(String razao_ar) {
		this.razao_ar = razao_ar;
	}


	public String getChave_pix_ar() {
		return chave_pix_ar;
	}


	public void setChave_pix_ar(String chave_pix_ar) {
		this.chave_pix_ar = chave_pix_ar;
	}
	
	
	


}

