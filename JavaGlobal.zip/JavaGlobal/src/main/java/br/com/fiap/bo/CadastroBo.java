package br.com.fiap.bo;


import java.sql.Connection;
import java.sql.SQLException;


import br.com.fiap.banco.dao.CadastroDao;
import br.com.fiap.banco.factory.ConnectionFactory;
import br.com.fiap.model.Cadastro;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;

public class CadastroBo {
	
	
    private CadastroDao cadastrodao;
    
    public CadastroBo() throws ClassNotFoundException, SQLException {
    	Connection conn = ConnectionFactory.getConnection();
    	this.cadastrodao = new CadastroDao(conn);
	}

    public void cadastrarBO(Cadastro cadastro) throws Excecao, ClassNotFoundException, SQLException{
        try {
            if (cadastro.getEmail_cd() == null || cadastro.getEmail_cd().isEmpty() || cadastro.getNm_cd() == null || cadastro.getNm_cd().isEmpty() ) {
                Response response = Response.status(Response.Status.BAD_REQUEST).entity("Erro nos dados do cadastro.").build();
                throw new WebApplicationException(response);
            } else {
                // Setando os valores diretamente
                cadastro.setId_cd(cadastro.getId_cd());
                cadastro.setNm_cd(cadastro.getNm_cd());
                cadastro.setEmail_cd(cadastro.getEmail_cd());
                cadastro.setSenha_cd(cadastro.getSenha_cd());
                cadastro.setFone_cd(cadastro.getFone_cd());

                // Realizando o cadastro no banco de dados utilizando o CadastroDao
                cadastrodao.cadastrar(cadastro);
            }
        } catch (SQLException e) {
            // Lidar com qualquer exceção SQL que possa ocorrer durante o cadastro
            e.printStackTrace(); // Aqui você pode implementar o tratamento adequado para o erro SQL
            Response response = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Erro interno no servidor.").build();
            throw new WebApplicationException(response);
        }
    }
}
