package br.com.fiap.model;

public class Especialista {
	
	private String crm_md;
	private String espc_md;
	private String nm_md;
	private String fone_md;
	
	
	public Especialista() {}

	public Especialista(String crm_md, String espc_md, String nm_md, String fone_md) {
		this.crm_md = crm_md;
		this.espc_md = espc_md;
		this.nm_md = nm_md;
		this.fone_md = fone_md;
	}

	public String getCrm_md() {
		return crm_md;
	}

	public void setCrm_md(String crm_md) {
		this.crm_md = crm_md;
	}

	public String getEspc_md() {
		return espc_md;
	}

	public void setEspc_md(String espc_md) {
		this.espc_md = espc_md;
	}

	public String getNm_md() {
		return nm_md;
	}

	public void setNm_md(String nm_md) {
		this.nm_md = nm_md;
	}

	public String getFone_md() {
		return fone_md;
	}

	public void setFone_md(String fone_md) {
		this.fone_md = fone_md;
	}
	
	
	
	
}
