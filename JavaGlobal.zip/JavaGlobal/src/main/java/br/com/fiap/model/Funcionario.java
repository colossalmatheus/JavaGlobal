package br.com.fiap.model;

public class Funcionario {
	
	private int id_fc;
	private String nm_fc;
	private String funcao_fc;
	
	public Funcionario() {}
	
	public Funcionario(int id_fc, String nm_fc, String funcao_fc) {
		this.id_fc = id_fc;
		this.nm_fc = nm_fc;
		this.funcao_fc = funcao_fc;
	}

	public int getId_fc() {
		return id_fc;
	}

	public void setId_fc(int id_fc) {
		this.id_fc = id_fc;
	}

	public String getNm_fc() {
		return nm_fc;
	}

	public void setNm_fc(String nm_fc) {
		this.nm_fc = nm_fc;
	}

	public String getFuncao_fc() {
		return funcao_fc;
	}

	public void setFuncao_fc(String funcao_fc) {
		this.funcao_fc = funcao_fc;
	}
	
	

}
