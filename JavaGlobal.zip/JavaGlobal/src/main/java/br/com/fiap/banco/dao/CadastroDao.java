package br.com.fiap.banco.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.banco.exception.IdNotFoundException;
import br.com.fiap.model.Cadastro;

public class CadastroDao {
	
	private Connection conn;

	public CadastroDao(Connection conn) {
		this.conn = conn;
	}

	public void cadastrar(Cadastro cadastro) throws ClassNotFoundException, SQLException {

		
		PreparedStatement stm = conn.prepareStatement("INSERT INTO cadastro (id_cd,nm_cd,email_cd,senha_cd,fone_cd) values (?,?,?,?,?)");

		
		stm.setString(1, cadastro.getId_cd());
		stm.setString(2, cadastro.getNm_cd());
		stm.setString(3,cadastro.getEmail_cd());
		stm.setString(4,cadastro.getSenha_cd());
		stm.setString(5,cadastro.getFone_cd());

		
		stm.executeUpdate();
		
	}

	public List<Cadastro> listar() throws ClassNotFoundException, SQLException {

		PreparedStatement stm = conn.prepareStatement("select * from cadastro");

		ResultSet result = stm.executeQuery();
		List<Cadastro> lista = new ArrayList<Cadastro>();

		while (result.next()) {
			Cadastro cadastro = parse(result);
			lista.add(cadastro);
		}
		
	
		return lista;
	}

	private Cadastro parse(ResultSet result) throws SQLException {

		String id_cd = result.getString("id_cd");
		String nm_cd = result.getString("nm_cd");
		String email_cd = result.getString("email_cd");
		String senha_cd = result.getString("senha_cd");
		String fone_cd = result.getString("fone_cd");
		
	

		Cadastro cadastro = new Cadastro(id_cd,nm_cd,email_cd,senha_cd,fone_cd);
		
		
		return cadastro;
	}
	
	
	public void remover(String id_cd) throws ClassNotFoundException, SQLException, IdNotFoundException {

		// PreparedStatement
		PreparedStatement stm = conn.prepareStatement("delete from cadastro where id_cd = ?");
		// Setar os parametros na Query
		stm.setString(1, id_cd);
		// Executar a Query
		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Cadastro nao encontrado para remocao");
		
	}

	public void atualizar(Cadastro cadastro) throws ClassNotFoundException, SQLException, IdNotFoundException {
		PreparedStatement stm = conn.prepareStatement("update cadastro set senha_cd = ? where id_cd = ?");
		stm.setString(1, cadastro.getSenha_cd());
		stm.setString(2, cadastro.getId_cd());

		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Id nao encontrado para atualizar");
		
	}
	
	

}
