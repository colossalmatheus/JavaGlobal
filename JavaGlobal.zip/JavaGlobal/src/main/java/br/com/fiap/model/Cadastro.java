package br.com.fiap.model;

public class Cadastro {
	
	private String id_cd;
	private String nm_cd;
	private String email_cd;
	private String senha_cd;
	private String fone_cd;
	
	public Cadastro() {}
	
	public Cadastro(String id_cd, String nm_cd, String email_cd, String senha_cd, String fone_cd) {
		this.id_cd = id_cd;
		this.nm_cd = nm_cd;
		this.email_cd = email_cd;
		this.senha_cd = senha_cd;
		this.fone_cd = fone_cd;
	}
	
	public String getId_cd() {
		return id_cd;
	}



	public void setId_cd(String id_cd) {
		this.id_cd = id_cd;
	}



	public String getNm_cd() {
		return nm_cd;
	}



	public void setNm_cd(String nm_cd) {
		this.nm_cd = nm_cd;
	}



	public String getEmail_cd() {
		return email_cd;
	}



	public void setEmail_cd(String email_cd) {
		this.email_cd = email_cd;
	}



	public String getSenha_cd() {
		return senha_cd;
	}



	public void setSenha_cd(String senha_cd) {
		this.senha_cd = senha_cd;
	}



	public String getFone_cd() {
		return fone_cd;
	}



	public void setFone_cd(String fone_cd) {
		this.fone_cd = fone_cd;
	}




	
}
