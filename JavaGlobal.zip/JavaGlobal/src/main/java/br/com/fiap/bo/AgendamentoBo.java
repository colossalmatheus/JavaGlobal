package br.com.fiap.bo;

import java.sql.Connection;
import java.sql.SQLException;
import br.com.fiap.banco.dao.AgendamentoDao;
import br.com.fiap.banco.factory.ConnectionFactory;
import br.com.fiap.model.Agendamento;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;

public class AgendamentoBo {

    
    private AgendamentoDao agendamentodao;

    

    public AgendamentoBo() throws ClassNotFoundException, SQLException {
    	Connection conn = ConnectionFactory.getConnection();
    	this.agendamentodao = new AgendamentoDao(conn);
	}

	public void cadastrarBO(Agendamento agendamento) throws Excecao, ClassNotFoundException, SQLException {
        
			if (agendamento.getTitulo_ag() == null || agendamento.getTitulo_ag().isEmpty() || agendamento.getLink_ag() == null || agendamento.getLink_ag().isEmpty()) {
			    Response response = Response.status(Response.Status.BAD_REQUEST).entity("Erro nos dados do agendamento.").build();
			    throw new WebApplicationException(response);
			} else {
                // Setando os valores diretamente
                agendamento.setId_ag(agendamento.getId_ag());
                agendamento.setTitulo_ag(agendamento.getTitulo_ag());
                agendamento.setDatahr_ag(agendamento.getDatahr_ag());
                agendamento.setLink_ag(agendamento.getLink_ag());

                // Realizando o cadastro no banco de dados utilizando o AgendamentoDao
                agendamentodao.cadastrar(agendamento);
            }
        
    }
}
