package br.com.fiap.model;

public class Agendamento {

	private String id_ag;
	private String titulo_ag;
	private String datahr_ag;
	private String link_ag;

	public Agendamento() {}
	
	public Agendamento(String id_ag, String titulo_ag, String datahr_ag, String link_ag) {
		this.id_ag = id_ag;
		this.titulo_ag = titulo_ag;
		this.datahr_ag = datahr_ag;
		this.link_ag = link_ag;
	}

	public String getId_ag() {
		return id_ag;
	}

	public void setId_ag(String id_ag) {
		this.id_ag = id_ag;
	}

	public String getTitulo_ag() {
		return titulo_ag;
	}

	public void setTitulo_ag(String titulo_ag) {
		this.titulo_ag = titulo_ag;
	}

	public String getDatahr_ag() {
		return datahr_ag;
	}

	public void setDatahr_ag(String datahr_ag) {
		this.datahr_ag = datahr_ag;
	}

	public String getLink_ag() {
		return link_ag;
	}

	public void setLink_ag(String link_ag) {
		this.link_ag = link_ag;
	}
	
	


}

