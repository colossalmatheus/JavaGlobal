package br.com.fiap.banco.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;


import br.com.fiap.banco.dao.EspecialistaDao;
import br.com.fiap.banco.exception.BadInfoException;
import br.com.fiap.banco.exception.IdNotFoundException;
import br.com.fiap.banco.factory.ConnectionFactory;

import br.com.fiap.model.Especialista;

public class EspecialistaService {
	
private EspecialistaDao especialistaDao;
	
	public EspecialistaService() throws ClassNotFoundException, SQLException {
		Connection conn = ConnectionFactory.getConnection();
		especialistaDao = new EspecialistaDao(conn);

	}
	
	
	public void cadastrar(Especialista especialista) throws ClassNotFoundException, SQLException, BadInfoException {
		especialistaDao.cadastrar(especialista);
	}
	
	
	public List<Especialista> listar() throws ClassNotFoundException, SQLException{
		return especialistaDao.listar();
	}
	
	public void remover(String crm_md) throws ClassNotFoundException, SQLException, IdNotFoundException {
		especialistaDao.remover(crm_md);
	}

	
	public void atualizar(Especialista especialista) throws ClassNotFoundException, SQLException, IdNotFoundException, BadInfoException {
		especialistaDao.atualizar(especialista);
	}

	
	

}
